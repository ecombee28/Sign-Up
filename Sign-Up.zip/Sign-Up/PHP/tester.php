<?php

session_start();
      header("Access-Control-Allow-Origin: *"); 
      $host = "localhost";
      $user = "combeons_ecombee";
      $password == "Jorden2009";
      $db = "combeons_MainDatabase";

      $conn = mysqli_connect($host, $user, $password, $db);

     if ($conn->connect_error) {
         die("Connection failed: " . $conn->connect_error);
      }else{
          echo 'It worked';
      }


?>